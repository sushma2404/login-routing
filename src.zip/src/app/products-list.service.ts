
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductList } from './Products';
@Injectable({
  providedIn: 'root'
})
export class ProductsListService {

  constructor(private http: HttpClient) { }
url:string = '/assets/Data/products.json';
getAllProducts(): Observable<ProductList[]>
{
     return this.http.get<ProductList[]>(this.url);
}


}

