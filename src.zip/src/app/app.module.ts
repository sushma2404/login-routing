import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { SearchFormComponent } from './search-form/search-form.component';
import { ProductsListComponent } from './products-list/products-list.component';
import {RouterModule, Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { ProductsListService } from './products-list.service';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
 const routes: Routes = [
   {path:'',redirectTo:'search-form', pathMatch:'full'},
  {path: 'search-form', component: SearchFormComponent,},
  {path: 'product-list', component: ProductsListComponent}

];
@NgModule({
  declarations: [
    AppComponent,
    SearchFormComponent,
    ProductsListComponent
  ],
  imports: [
    BrowserModule,
   RouterModule.forRoot(routes),
   HttpClientModule,
    AppRoutingModule,
    FormsModule,
  ],
  providers: [ProductsListService],
  bootstrap: [AppComponent]
})
export class AppModule { }

