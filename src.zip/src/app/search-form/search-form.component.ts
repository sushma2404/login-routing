import { Component, OnInit } from '@angular/core';
import { ProductsListService } from '../products-list.service';
import { ProductList } from '../Products';
@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {

  constructor(private servics: ProductsListService) { }
  proList: ProductList[];
searchList: ProductList[];

  ngOnInit() {
    this.getAllProducts();
  }
  getAllProducts()
  {
    this.servics.getAllProducts().subscribe(Data => this.proList = Data);
  }
  search(myform)
  {
    console.log(this.proList.length);
    for(let i = 0; i < this.proList.length; i++)
    {
      console.log(i);
      console.log(this.proList[i].id);
      console.log(myform.value.id);

      if(this.proList[i].id!=myform.value.id)
      {
        this.proList.splice(i,1);

      }

    }

  }
}
