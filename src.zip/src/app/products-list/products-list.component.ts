import { Component, OnInit } from '@angular/core';
import { ProductsListService } from '../products-list.service';
import { ProductList } from '../Products';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {

  constructor(private servics: ProductsListService) { }
  proList: ProductList[];

  ngOnInit() {
    this.getAllProducts();
  }
  getAllProducts()
  {
    this.servics.getAllProducts().subscribe(Data => this.proList = Data);
  }

}
